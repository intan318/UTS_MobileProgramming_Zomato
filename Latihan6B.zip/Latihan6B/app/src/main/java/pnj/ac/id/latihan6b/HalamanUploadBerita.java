package pnj.ac.id.latihan6b;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HalamanUploadBerita extends AppCompatActivity {

    Button actionClose;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_halaman_upload_berita);

        actionClose = findViewById(R.id.actionClose);
        actionClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent();
                intent.putExtra("data1","Syamsi");
                intent.putExtra("data2","PNJ");
                intent.putExtra("data3","TIK");

                setResult(Activity.RESULT_OK,intent);
                finish();






            }
        });
    }
}
